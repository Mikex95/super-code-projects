let timeOutput = document.getElementById('time');
let timeInput = document.getElementById('minutes');

let second = 10;
let minute = 1;

const countdown = function(){
    let time = `${minute} : ${second--}`
    console.log(time);
    if (second == 0) {
        second = 59;
        time = `${minute--} : ${second}`
    } if (second <= 0 && minute <= 0){
        clearInterval(interval)
    }
}

let interval = setInterval(countdown, 200);

const startMinCountdown = function(){
    
}


function pauseMinCountdown(){
    clearInterval(interval)
}

function restartMinCountdown(){
   
}

