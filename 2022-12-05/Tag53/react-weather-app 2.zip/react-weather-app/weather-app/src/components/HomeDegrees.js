const HomeDegrees = (props) => {
    return ( <div>
        <p></p>
        <p></p>
    </div> );
}
 
export default HomeDegrees;