
const HomeCoords = (props) => {
    return ( <div>
        <p>Coordinates: {props.lon}, {props.lat}</p>
    </div> );
}
 
export default HomeCoords;