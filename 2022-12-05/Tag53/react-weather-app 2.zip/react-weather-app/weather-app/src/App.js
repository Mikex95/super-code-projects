import './App.css';
import Home from './pages/Home';
import Footer from './pages/Footer';
import HomeTest from "./pages/HomeTest";

function App() {
  return (
    <div className="App">
      <HomeTest></HomeTest>
      {/* <Home></Home> */}
      <Footer></Footer>
    </div>
  );
}

export default App;
