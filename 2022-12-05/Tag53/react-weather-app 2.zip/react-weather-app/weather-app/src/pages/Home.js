// import React, { useState, useEffect } from 'react';
import "./Home.css"

const Home = () => {
    // const [data, setData] = useState([]);
    // const [location, setLocation] = useState("");
    // const [forecast, setForecast] = useState([])
    // const [lat, setLat] = useState("");
    // const [lon, setLon] = useState("");

    // function handleClick() {
    //     const inputvalue = document.querySelector("input").value
    //     setLocation(inputvalue);
    //     setLon(data[0].lon)
    //     setLat(data[0].lat)
    //     // fetchData()
    // }

    // console.log(location);
    const api_key = "c27a1a351c4c3b87fbecf99ff89ca287";

    //   const fetchData = () => {

//     fetch(`http://api.openweathermap.org/geo/1.0/direct?q=${location}&appid=${api_key}`)
//       .then(response => response.json())
//       .then((json) => {
//         setData(json)
//         fetch(`https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${api_key}&units=metric`)
//         .then(response => response.json())
//         .then(json => setForecast(json))
//           })
//   }
//   useEffect(fetchData, [api_key, location, lat, lon])
//     console.log("data:",data);
//     console.log("hallo:",forecast);

    const inputField = () => {
        return (  
           <>
           <h1>Test</h1>
            {/* <input
            type="text"
           id="message"
           name="message"
           placeholder="Search City"
           />
            <button onClick={handleClick}>Check Weather</button> */}
            </>
        );
    }
    inputField();

    const test=()=>{
        return( <h1>Test</h1>);
    }

    // const showWeather = () => {
        
    //     if (Object.keys(forecast).length > 0) {
    //         return;
    //     }
    //     if(Array.isArray(forecast)){
    //         if(forecast.length===0){
    //             return ;
    //         }
    //     }
        
        
    //         console.log(forecast);
    //         return ( <div className="wrapper-home">
    //      <div className="container-home">
    //      {/* <h2 className="main-city">{data[0].name}</h2> */}
    //     <p className="main-temp">{forecast.list[0].main.temp_max.toFixed(1)}C°</p>
    //     <p className="main-description">{forecast.list[0].weather[0].description}</p>
    //     <div className="wrapper-forecast">
    //         <h2 className="main-city-forecast">{forecast.list[6].dt_txt.replace("09:00:00", "")}</h2>
    //         <p className="main-temp-forecast">{forecast.list[6].main.temp_max.toFixed(1)}C°</p>
    //         <p className="main-description-forecast">{forecast.list[6].weather[0].description}</p>  
    //     </div>    
    //     <div className="wrapper-forecast">
    //         <h2 className="main-city-forecast">{forecast.list[14].dt_txt.replace("09:00:00", "")}</h2>
    //         <p className="main-temp-forecast">{forecast.list[14].main.temp_max.toFixed(1)}C°</p>
    //         <p className="main-description-forecast">{forecast.list[14].weather[0].description}</p>  
    //     </div>    
    //     <div className="wrapper-forecast">
    //         <h2 className="main-city-forecast">{forecast.list[22].dt_txt.replace("09:00:00", "")}</h2>
    //         <p className="main-temp-forecast">{forecast.list[22].main.temp_max.toFixed(1)}C°</p>
    //         <p className="main-description-forecast">{forecast.list[22].weather[0].description}</p>  
    //     </div>    
    //   </div>
    // </div> );

    //     }
        // showWeather();
        test();
        // inputField();


//     return ( <div className="wrapper-home">
//         <div className="container-home">
//         <h2 className="main-city">{data[0].name}</h2>
//         <p className="main-temp">{forecast.list[0].main.temp_max.toFixed(1)}C°</p>
//         <p className="main-description">{forecast.list[0].weather[0].description}</p>
//           <input
//         type="text"
//         id="message"
//         name="message"
//         placeholder="Search City"
//       />
//       <button onClick={handleClick}>Check Weather</button>
//         <div className="wrapper-forecast">
//             <h2 className="main-city-forecast">{forecast.list[6].dt_txt.replace("09:00:00", "")}</h2>
//             <p className="main-temp-forecast">{forecast.list[6].main.temp_max.toFixed(1)}C°</p>
//             <p className="main-description-forecast">{forecast.list[6].weather[0].description}</p>  
//         </div>    
//         <div className="wrapper-forecast">
//             <h2 className="main-city-forecast">{forecast.list[14].dt_txt.replace("09:00:00", "")}</h2>
//             <p className="main-temp-forecast">{forecast.list[14].main.temp_max.toFixed(1)}C°</p>
//             <p className="main-description-forecast">{forecast.list[14].weather[0].description}</p>  
//         </div>    
//         <div className="wrapper-forecast">
//             <h2 className="main-city-forecast">{forecast.list[22].dt_txt.replace("09:00:00", "")}</h2>
//             <p className="main-temp-forecast">{forecast.list[22].main.temp_max.toFixed(1)}C°</p>
//             <p className="main-description-forecast">{forecast.list[22].weather[0].description}</p>  
//         </div>    
//       </div>
//     </div> );
// }

}
export default Home; 